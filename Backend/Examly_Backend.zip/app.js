const express = require("express");
const dotEnv = require("dotenv");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const app = express();

const connectDB = require("./utils/connectDB");
dotEnv.config();
//Connecting mongodb
connectDB();
//cors
const corsOptions = {
  //To allow requests from client
  origin: ["http://localhost:3001"],
  credentials: true,
};
app.use(cors(corsOptions));
//bodyparser
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
//Routes
app.get("/", (req, res) => {
  res.send("Automated Examination System using NLP");
});
//Listening to server
app.listen(process.env.PORT || 3000, () =>
  console.log(`App started on port ${process.env.PORT}`)
);
module.exports = app;
